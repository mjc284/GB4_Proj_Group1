SpeechRecognizer.zip contains
-commandRecognition.m (MATLAB script for voice command recognition)
-commandNet.mat (MATLAB data file containing a pre-trained neural network for voice commands ("UP" or "DOWN") recognition)
-helperExtractAuditoryFeatures.m (A supporting function required by commandRecognition.m)
-weightedClassificationLayer.m (A class file required by commandRecognition.m)
-readMe.txt (instructions on how to run commandRecognition.m)


To test the speech command recognizer: 
-Files must be located in the same working directory. 
-Run 'commandRecognition.m'. 


